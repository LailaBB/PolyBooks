PolyBooks is a web application that allows Polytechs’ teachers to put into students disposition academic documents in different modules taught at Polytech.
On this application we have the different modules displayed on shelves (like on a store’s window), then when picking a module we find inside the list of documents attached to it sorted out in a specific order.
=======

Developped by Laila Ben Brahim
